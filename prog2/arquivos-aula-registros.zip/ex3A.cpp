/* Recebe duas datas (dd/mm/aaaa) e calcula o numero de dias decorridos entre elas*/
#include <stdio.h>
#include <math.h>

// definição de um tipo estrutura/registro/struct
struct tipoData
{
	int dia, mes, ano;
};


int fAno(int ano, int mes)
{

}

int gMes(int mes)
{

}

int calculaN(tipoData data1, tipoData data2)
{


}

int main()
{

	return 0;
}